﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Raktarprogram
{
    public partial class Form5 : Form
    {
        class adatok
        {
            public string termek;
            public DateTime date;
            public int db;
        }

       
        public Form5()
        {
            InitializeComponent();
            
            StreamReader sr = new StreamReader("eladasok.txt");
            List<adatok> list = new List<adatok>();

            while (!sr.EndOfStream)
            {
                string sor = sr.ReadLine();
                string[] darabok = sor.Split(';');
                adatok a = new adatok();
                a.termek = darabok[0];
                a.date = Convert.ToDateTime(darabok[1]);
                a.db =Convert.ToInt32(darabok[2]);
                list.Add(a);

            }
            sr.Close();

            Dictionary<string, int> stat = new Dictionary<string, int>();

            foreach (var item in list)
            {
                if (!stat.ContainsKey(item.termek))
                {
                    stat.Add(item.termek, item.db);
                }
                else{
                    stat[item.termek] += item.db;
                }
            }

            DataTable table = new DataTable();
            table.Columns.Add("Termék", typeof(string));
            table.Columns.Add("Összmennyiség", typeof(string));
          

            foreach (var item in stat)
            {
                table.Rows.Add(item.Key, item.Value);

            }



            dataGridView1.DataSource = table;

        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            if (printPreviewDialog1.ShowDialog()==DialogResult.OK)
            {
                printDocument1.Print();
            }
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dataGridView1.Width, this.dataGridView1.Height);
            dataGridView1.DrawToBitmap(bm, new Rectangle(0, 0, this.dataGridView1.Width, this.dataGridView1.Height));
            e.Graphics.DrawImage(bm, 0, 0);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
           

            
        }
    }
}
