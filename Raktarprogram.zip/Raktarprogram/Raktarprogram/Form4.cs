﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Raktarprogram
{
    public partial class Form4 : Form
    {
        class adatok
        {
            public int szam;
            public string termek;
        }
        public Form4()
        {
            InitializeComponent();
            

            StreamReader sr = new StreamReader("termekek.txt");
            List<adatok> list = new List<adatok>();

            while (!sr.EndOfStream)
            {
                string sor = sr.ReadLine();
                string[] darabok = sor.Split(';');
                adatok a = new adatok();
                a.szam = Convert.ToInt32(darabok[0]);
                a.termek = darabok[1];
                list.Add(a);

            }
            sr.Close();

            foreach (var item in list)
            {
                comboBox1.Items.Add(item.termek);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)

        {

            StreamWriter sw = new StreamWriter("eladasok.txt",true);

            sw.Write(comboBox1.Text+";"+Convert.ToDateTime(dateTimePicker1.Text)+";"+numericUpDown1.Value+"\n");
            
            sw.Close();

            MessageBox.Show("Sikeres felvétel!");
        }
    }
}
