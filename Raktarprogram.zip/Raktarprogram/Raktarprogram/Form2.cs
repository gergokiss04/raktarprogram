﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Raktarprogram
{
    public partial class Form2 : Form
    {
        class adatok
        {
           public int szam;
           public string termek;
        }

        public Form2()
        {
            InitializeComponent();
            
            StreamReader sr = new StreamReader("termekek.txt");
            List<adatok> list = new List<adatok>();

            while (!sr.EndOfStream)
            {
                string sor = sr.ReadLine();
                string[] darabok = sor.Split(';');
                adatok a = new adatok();
                a.szam = Convert.ToInt32(darabok[0]);
                a.termek = darabok[1];
                list.Add(a);

            }
            sr.Close();

            foreach (var item in list)
            {
                richTextBox1.Text += item.szam.ToString() + " " + item.termek + " \n";
            }
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            StreamReader sr = new StreamReader("termekek.txt");
            List<adatok> list = new List<adatok>();
           

            while (!sr.EndOfStream)
            {
                string sor = sr.ReadLine();
                string[] darabok = sor.Split(';');
                adatok a = new adatok();
                a.szam = Convert.ToInt32(darabok[0]);
                a.termek = darabok[1];
                list.Add(a);
                

            }
            sr.Close();
            

            foreach (var item in list)
            {
                if (item.szam==Convert.ToInt32(textBox3.Text))
                {
                    list.Remove(item);
                    MessageBox.Show("Siker");
                    break;
                    
                }
            }

            StreamWriter sw = new StreamWriter("termekek.txt");
            foreach (var item in list)
            {
                sw.WriteLine(item.szam + ";" + item.termek);
            }
            sw.Close();
            richTextBox1.Clear();
            richTextBox1.Text = File.ReadAllText("termekek.txt");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("termekek.txt",true);
            sw.WriteLine(textBox1.Text + ";" + textBox2.Text);
            textBox1.Text = "";
            sw.Close();
            richTextBox1.Text=File.ReadAllText("termekek.txt");
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
